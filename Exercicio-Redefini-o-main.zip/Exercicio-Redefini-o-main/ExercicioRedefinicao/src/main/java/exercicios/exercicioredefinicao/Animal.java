/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios.exercicioredefinicao;

/**
 *
 * @author allan
 */
public class Animal {
    public void fazerBarulho(){
        System.out.println("O animal está fazendo barulho");
    }
}
